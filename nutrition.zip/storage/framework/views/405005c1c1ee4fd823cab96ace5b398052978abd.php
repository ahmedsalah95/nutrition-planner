<?php $__env->startSection('content'); ?>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>


    <?php if($errors->all()): ?>
        <div style="color: #a94442; background-color: #f2dede; border-color: #ebccd1;" class="alert ">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>



    <div class="container">

        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12">
                <a href="<?php echo e(url('/')); ?>/patient/create" class="btn btn-success btn-block">اضافة مريض جديد</a>
            </div>
        </div>
    </div>
    <br>
    <hr>
    <br>
    <br>
    <input class="form-control" id="myInput" type="text" placeholder="البحث بالاسم او رقم الهاتف">
    <br>
    <section class="indexPatient">
        <div class="container">
            <div class="row">

                <table class="table table-bordered table-striped">
                    <thead>
                    <tr>
                        <th>الاسم</th>

                        <th>رقم الهاتف</th>
                        <th> مسح\تعديل </th>
                    </tr>
                    </thead>
                    <tbody id="myTable">
                    <?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($patient->name); ?></td>
                        <td><?php echo e($patient->phone); ?></td>

                        <td>

                            <a href="/patient/<?php echo e($patient->id); ?>/edit" class="btn btn-warning"><i class="fa fa-pencil"></i></a>
                            <a href="#" onclick="event.preventDefault();
                                    document.getElementById('delete-form<?php echo e($patient->id); ?>').submit();"
                               style="font-size: 20px;margin-right: 5px;color: #D73925;">
                                <i class="fa fa-trash-o" aria-hidden="true"></i></a>
                            <form id="delete-form<?php echo e($patient->id); ?>"
                                  action="<?php echo e(url('/patient/'.$patient->id)); ?>"
                                  method="post"
                                  style="display: none;">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="_method" value="delete"/>

                            </form>
                            <a href="/patient/<?php echo e($patient->id); ?>" class="btn btn-success"> <i class="fa fa-eye"></i></a>
                        </td>
                    </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </tbody>

                </table>

                    <center><?php echo e($patients->links()); ?></center>
            </div>
        </div>


    </section>



    <script>
        $(document).ready(function(){
            $("#myInput").on("keyup", function() {
                var value = $(this).val().toLowerCase();
                $("#myTable tr").filter(function() {
                    $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>