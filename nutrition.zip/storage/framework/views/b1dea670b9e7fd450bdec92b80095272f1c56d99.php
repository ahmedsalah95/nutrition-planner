<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.0/jquery.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<!-- Parsley -->
<script src="<?php echo e(url('/')); ?>/vendors/parsleyjs/dist/parsley.min.js"></script>
<!-- jQuery -->
<script src="<?php echo e(url('/')); ?>/vendors/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap -->
<script src="<?php echo e(url('/')); ?>/vendors/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- FastClick -->
<script src="<?php echo e(url('/')); ?>/vendors/fastclick/lib/fastclick.js"></script>
<!-- NProgress -->
<script src="<?php echo e(url('/')); ?>/vendors/nprogress/nprogress.js"></script>
<!-- bootstrap-progressbar -->
<script src="<?php echo e(url('/')); ?>/vendors/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>
<!-- iCheck -->
<script src="<?php echo e(url('/')); ?>/vendors/iCheck/icheck.min.js"></script>
<!-- bootstrap-daterangepicker -->
<script src="<?php echo e(url('/')); ?>/vendors/moment/min/moment.min.js"></script>
<script src="<?php echo e(url('/')); ?>/vendors/bootstrap-daterangepicker/daterangepicker.js"></script>
<!-- bootstrap-wysiwyg -->
<script src="<?php echo e(url('/')); ?>/vendors/bootstrap-wysiwyg/js/bootstrap-wysiwyg.min.js"></script>
<script src="<?php echo e(url('/')); ?>/vendors/jquery.hotkeys/jquery.hotkeys.js"></script>
<script src="<?php echo e(url('/')); ?>/vendors/google-code-prettify/src/prettify.js"></script>
<!-- jQuery Tags Input -->
<script src="<?php echo e(url('/')); ?>/vendors/jquery.tagsinput/src/jquery.tagsinput.js"></script>
<!-- Switchery -->
<script src="<?php echo e(url('/')); ?>/vendors/switchery/dist/switchery.min.js"></script>
<!-- Select2 -->
<script src="<?php echo e(url('/')); ?>/vendors/select2/dist/js/select2.full.min.js"></script>

<!-- Autosize -->
<script src="<?php echo e(url('/')); ?>/vendors/autosize/dist/autosize.min.js"></script>
<!-- jQuery autocomplete -->
<script src="<?php echo e(url('/')); ?>/vendors/devbridge-autocomplete/dist/jquery.autocomplete.min.js"></script>
<!-- starrr -->
<script src="<?php echo e(url('/')); ?>/vendors/starrr/dist/starrr.js"></script>
<!-- Custom Theme Scripts -->
<script src="<?php echo e(url('/')); ?>/build/js/custom.min.js"></script>

<script src="<?php echo e(url('/')); ?>/vendors/bootstrap-tagsinput.min.js"></script>

<script src="<?php echo e(url('/')); ?>/vendors/accordination.js"></script>








