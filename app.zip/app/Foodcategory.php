<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Foodcategory extends Model
{

}
