<!-- footer content -->
<footer>
    <div class="pull-right">
        hadeel mosleh  <a href="#">2018</a>
    </div>
    <div class="clearfix"></div>
</footer>
<!-- /footer content -->