<!DOCTYPE html>
<html lang="en">
<?php echo $__env->make('dashboard.partial.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<body class="nav-md">
<div class="container body">
    <div class="main_container">


    <?php echo $__env->make('dashboard.partial.sideMenu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('dashboard.partial.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


    <!-- page content -->
        <div class="right_col" role="main">
            <?php echo $__env->yieldContent('content'); ?>
           
        </div>

        <!-- /page content -->
        <?php echo $__env->make('dashboard.partial.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


    </div>
</div>
<?php echo $__env->make('dashboard.partial.script', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>
</html>
