<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Nutrition</title>

    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
    <!-- Bootstrap -->
    <link href="<?php echo e(url('/')); ?>/vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="<?php echo e(url('/')); ?>/vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="<?php echo e(url('/')); ?>/vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- iCheck -->
    <link href="<?php echo e(url('/')); ?>/vendors/iCheck/skins/flat/green.css" rel="stylesheet">
    <!-- bootstrap-wysiwyg -->
    <link href="<?php echo e(url('/')); ?>/vendors/google-code-prettify/bin/prettify.min.css" rel="stylesheet">
    <!-- Select2 -->
    <link href="<?php echo e(url('/')); ?>/vendors/select2/dist/css/select2.min.css" rel="stylesheet">
    <!-- Switchery -->
    <link href="<?php echo e(url('/')); ?>/vendors/switchery/dist/switchery.min.css" rel="stylesheet">
    <!-- starrr -->
    <link href="<?php echo e(url('/')); ?>/vendors/starrr/dist/starrr.css" rel="stylesheet">
    <!-- bootstrap-daterangepicker -->
    <link href="<?php echo e(url('/')); ?>/vendors/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="<?php echo e(url('/')); ?>/build/css/custom.min.css" rel="stylesheet">

    <link href="<?php echo e(url('/')); ?>/vendors/bootstrap-tagsinput.css" rel="stylesheet">

    <!-- adding textext -->
    <link  href="<?php echo e(url('/')); ?>/vendors/textext.core.css" rel="stylesheet">

    <link  href="<?php echo e(url('/')); ?>/vendors/textext.plugin.arrow.css" rel="stylesheet">

    <link  href="<?php echo e(url('/')); ?>/vendors/textext.plugin.autocomplete.css" rel="stylesheet">

    <link  href="<?php echo e(url('/')); ?>/vendors/textext.plugin.clear.css" rel="stylesheet">

    <link  href="<?php echo e(url('/')); ?>/vendors/textext.plugin.focus.css" rel="stylesheet">

    <link  href="<?php echo e(url('/')); ?>/vendors/textext.plugin.prompt.css" rel="stylesheet">

    <link  href="<?php echo e(url('/')); ?>/vendors/textext.plugin.tags.css" rel="stylesheet">

    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/vendors/accordination.css">
</head>
